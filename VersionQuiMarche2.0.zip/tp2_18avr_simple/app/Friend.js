FbApp.Friend = Backbone.Model.extend({

});
