FbApp.ChartView = Backbone.View.extend({

	initialize: function(){
	},

	render: function(){

 	}

})