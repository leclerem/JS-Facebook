FbApp.RelationShipChartModel = FbApp.ChartModel.extend({
	processData: function(){
		// Récupération des attributs
		var data=[];
		this.collection.forEach(function(friend){
			data[friend.get('relationship_status')] += 1;			
		});

		for(var i in data)
		{
		    data[i] = 0;
		}

		// Attribution des valeurs à chaque attributs
		this.collection.forEach(function(friend){
			data[friend.get('relationship_status')] += 1;			
		});

		var dataTemp = [];

		// Génération du tableau pour le data d'Highcharts

		for(var i in data)
		{
			if(i != "null"){
				dataTemp.push([i, data[i]]);
			} else {
				dataTemp.push(['Non Déterminé', data[i]]);
			}
			
		    console.log(i + "=" + data[i]);
		}
		this.set('chartData', dataTemp);
		console.log(this.get('chartData'));
	}
});
